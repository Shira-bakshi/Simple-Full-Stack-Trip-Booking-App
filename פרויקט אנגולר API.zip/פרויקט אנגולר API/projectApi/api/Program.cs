﻿using BLL.func;
using BLL.inter;
using DAL.dataT;
using DAL.func;
using DAL.inter;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.EntityFrameworkCore;

namespace api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddCors(opotion => opotion.AddPolicy("AllowAll",//ðúéðú ùí ìäøùàä
                p => p.AllowAnyOrigin()//îàôùø ëì î÷åø
                .AllowAnyMethod()//ëì îúåãä - ôåð÷öéä
                .AllowAnyHeader()));//åëì ëåúøú ôåð÷öéä

//צריך טיפול באותיות גדולות- למחוק אם לא 
            builder.Services.AddControllers()
           .AddJsonOptions(opts => opts.JsonSerializerOptions.PropertyNamingPolicy = null);

            builder.Services.AddDbContext<TravelsContext>(
                a => a.UseSqlServer("Server = SHIRA\\SQLEXPRESS; Database = Travels; Trusted_Connection = True; TrustServerCertificate = True"));

            builder.Services.AddScoped(typeof(IBookingPlaceDAL), typeof(BookingPlaceDAL));
            builder.Services.AddScoped(typeof(ITravelTypeDAL), typeof(TravelTypeDAl));
            builder.Services.AddScoped(typeof(ITripDAL), typeof(TripDAL));
            builder.Services.AddScoped(typeof(IUserDAL), typeof(UserDAL));
            builder.Services.AddScoped(typeof(IBookingPlaceBLL), typeof(BookingPlaceBLL));
            builder.Services.AddScoped(typeof(ITravelTypeBLL), typeof(TravelTypeBLL));
            builder.Services.AddScoped(typeof(ITripBLL), typeof(TripBLL));
            builder.Services.AddScoped(typeof(IUserBLL), typeof(UserBLL));

            var app = builder.Build();
            app.UseCors("AllowAll");

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}