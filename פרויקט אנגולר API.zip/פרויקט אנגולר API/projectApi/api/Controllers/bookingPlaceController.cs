﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class bookingPlaceController : ControllerBase
    {
        IBookingPlaceBLL bll;

        public bookingPlaceController(IBookingPlaceBLL bll)
        {
            this.bll = bll;
        }

        [HttpPost("AddInviteToTrip")]

        public ActionResult<int> AddInviteToTrip(BookingPlaceDTO trip)
        {
            return Ok(bll.addB(trip));
        }
        [HttpDelete("deletbp")]
        public ActionResult<bool> deletbp(int id)
        {
            return Ok(bll.deleteBookingPlace(id));
        }
        [HttpGet("GetAllInviteToTrip/{id}")]
        public ActionResult<List<BookingPlaceDTO>> GetAllInviteToTrip(int id)
        {
            return Ok(bll.getAllToTrip(id));
        }
 
    }
}
