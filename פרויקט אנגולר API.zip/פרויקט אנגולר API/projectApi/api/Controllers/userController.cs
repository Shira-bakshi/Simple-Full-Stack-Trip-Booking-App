﻿using BLL.DTO;
using BLL.inter;
using DAL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class userController : ControllerBase
    {
        IUserBLL bll;

        public userController(IUserBLL bll)
        {
            this.bll = bll;
        }
        [HttpGet("GetAllUsers")]
        public ActionResult<List<UserDTO>> GetAllUsers()
        {
            return Ok(bll.getAll());
        }
        [HttpGet("GetUserByMailAndPassword/{email}/{password}")]
        public ActionResult<UserDTO> GetUserByMailAndPassword(string email, string password)
        {
            return Ok(bll.GetUserByMailAndPassword(email, password));
        }

        [HttpPost("AddUser")]
        public ActionResult<int> AddUser(UserDTO user)
        {
            return Ok(bll.addUser(user));
        }
        [HttpPut("UpdateUser")]
        public ActionResult<bool> UpdateUser(UserDTO user)
        {
            return Ok(bll.updateUser(user));
        }
        [HttpDelete("DeleteUser/{id}")]
        public ActionResult<bool> DeleteUser(int id)
        {
            return Ok(bll.deleteUser(id));
        }
        [HttpGet("GetAllTripToUser/{id}")]
        public ActionResult<List<TripDTO>> GetAllTripToUser(int id)
        {
            return Ok(bll.getAllTrip(id));
        }
        
    }
}
