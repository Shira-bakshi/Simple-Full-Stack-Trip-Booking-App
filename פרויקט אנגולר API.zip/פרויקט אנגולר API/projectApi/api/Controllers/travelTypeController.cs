﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class travelTypeController : ControllerBase
    {
        ITravelTypeBLL bll;

        public travelTypeController(ITravelTypeBLL bll)
        {
            this.bll = bll;
        }
        [HttpGet("getAllTravelT")]
        public ActionResult<List<TravelTypeDTO>> getAllTravelT()
        {
            return Ok(bll.getAll());
        }
    }
}
