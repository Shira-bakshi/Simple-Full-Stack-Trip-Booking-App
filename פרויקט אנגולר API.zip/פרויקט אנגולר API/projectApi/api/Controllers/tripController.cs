﻿using BLL.DTO;
using BLL.inter;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tripController : ControllerBase
    {
        ITripBLL bll;

        public tripController(ITripBLL bll)
        {
            this.bll = bll;
        }
        [HttpGet("getAllT")]
        public ActionResult<List<TripDTO>> getAll()
        {
            return Ok(bll.getAll());
        }
        [HttpGet("getByIdT/{id}")]
        public ActionResult<TripDTO> getById(string id)
        {
            return Ok(bll.getByid(int.Parse(id)));
        }
        [HttpGet("GetInvitesToTripById/{id}")]
        public ActionResult<List<BookingPlaceDTO>> GetInvitesToTripById(string id)
        {
            return Ok(bll.GetInvitesToTrip(int.Parse(id)));
        }
        [HttpPost("AddTrip")]
        public ActionResult<int> AddTrip(TripDTO trip)
        {
            return Ok(AddTrip(trip));
        }

        [HttpPut("UpdateTrip")]
        public ActionResult<bool> UpdateTrip(TripDTO trip)
        {
            return Ok(bll.updateTrip(trip));
        }
        [HttpDelete("DeleteTrip/{id}")]
        public ActionResult<bool> DeleteTrip(int id) 
        {
            return Ok(bll.deletTrip(id));
        }




    }
}
