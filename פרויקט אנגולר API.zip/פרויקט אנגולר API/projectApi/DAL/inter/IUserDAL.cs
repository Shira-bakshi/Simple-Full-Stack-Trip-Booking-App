﻿using DAL.dataT;
using DAL.func;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.inter
{
    public interface IUserDAL
    {
        public List<User> getAll();
        public User byMailAndPasword(string mail, string password);
        public int addUser(User user);
        public bool deletUser(int id);
        public bool UpdateUser(User user);


    }
}
