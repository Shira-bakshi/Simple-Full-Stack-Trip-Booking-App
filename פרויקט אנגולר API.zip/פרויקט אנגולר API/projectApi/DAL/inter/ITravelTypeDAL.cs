﻿using DAL.dataT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.inter
{
    public interface ITravelTypeDAL
    {
        public List<TravelType> getAll();
        public TravelType getById(int id);
        public int addTravel(TravelType travelT);
        public bool deletTravelType(int id);


    }
}
