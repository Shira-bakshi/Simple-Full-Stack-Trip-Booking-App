﻿using DAL.dataT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.inter
{
    public interface ITripDAL
    {
        public List<Trip> getAll();
        public Trip getById(int id);
        public int addTrip(Trip trip);
        public bool deletTrip(int id);
        public bool UpdateTrip(Trip trip);


    }
}
