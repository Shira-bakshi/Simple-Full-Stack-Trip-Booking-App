﻿using DAL.dataT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.inter
{
    public interface IBookingPlaceDAL
    {
        public List<BookingPlace> getAll();
        public BookingPlace getById(int id);
        public int addBookingPlase(BookingPlace bookP);
        public bool deletBookingPlase(int id);


    }
}
