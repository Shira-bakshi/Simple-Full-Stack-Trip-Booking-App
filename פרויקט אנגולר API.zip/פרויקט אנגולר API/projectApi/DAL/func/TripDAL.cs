﻿using DAL.dataT;
using DAL.inter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DAL.func
{
    public class TripDAL:ITripDAL
    {
        TravelsContext db;

        public TripDAL(TravelsContext db)
        {
            this.db = db;
        }
        public List<Trip> getAll()
        {
            return db.Trips
                .Include(x=>x.BookingPlaces)
                .ThenInclude(x=> x.UserCodeNavigation)
                .Include(x=> x.TypeCodeNavigation)
                .ToList();
        }
        public Trip getById(int id) 
        {
            return db.Trips.FirstOrDefault(x => x.TripCode == id);

        }
        public int addTrip (Trip trip) 
        {
            db .Trips.Add(trip);
            db.SaveChanges();
            return trip.TripCode;
        }
        public bool deletTrip(int id)
        {
            try
            {
                db.Trips.Remove(getById(id));
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateTrip(Trip trip)
        {
            Trip t = db.Trips.FirstOrDefault(x => x.TripCode == trip.TripCode);
            if (t != null)
            {
                t.TripDestination= trip.TripDestination;
                t.TypeCode = trip.TypeCode;
                t.BookingPlaces = trip.BookingPlaces;
                //t.DepartureTime = trip.DepartureTime;
                t.Date= trip.Date;
                t.Photo = trip.Photo;
                t.Price = trip.Price;
                t.NumberOfAvailablePlaces= trip.NumberOfAvailablePlaces;
                db.SaveChanges();
                return true;
            }
            return false;


        }
    }

}
