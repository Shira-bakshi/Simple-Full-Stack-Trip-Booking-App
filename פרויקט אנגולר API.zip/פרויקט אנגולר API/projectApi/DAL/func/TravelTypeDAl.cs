﻿using DAL.dataT;
using DAL.inter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.func
{
    public class TravelTypeDAl:ITravelTypeDAL
    {
        TravelsContext db;

        public TravelTypeDAl(TravelsContext db)
        {
            this.db = db;
        }
        public List<TravelType> getAll()
        {
            return db.TravelTypes
                .Include(x => x.Trips)
                .ThenInclude(x => x.BookingPlaces)
                .ToList();
        }
        public TravelType getById(int id) 
        {
            return db.TravelTypes.FirstOrDefault(x => x.TypeCode == id);
        }
        public int addTravel(TravelType travelT) 
        {
            db.TravelTypes.Add(travelT);
            db.SaveChanges();
            return travelT.TypeCode;
        }
        public bool deletTravelType(int id)
        {
            try
            {
                db.TravelTypes.Remove(getById(id));
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
