﻿using DAL.dataT;
using DAL.inter;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.func
{
    public class UserDAL:IUserDAL
    {
        TravelsContext db;

        public UserDAL(TravelsContext db)
        {
            this.db = db;
        }
        public List<User> getAll()
        {
            return db.Users
                .Include(x=>x.BookingPlaces)
                .ThenInclude(x=>x.TripCodeNavigation)
                .ToList();
        }
        public User byMailAndPasword(string mail, string password)
        {
            return db.Users.FirstOrDefault(x => x.Email == mail && x.LoginPassword == password);
        }
        public int addUser(User user)
        {
            db.Users.Add(user);
            db.SaveChanges();
            return user.UserCode;
        }
        public bool deletUser(int id)
        {
            try
            {
                db.Users.Remove(db.Users.FirstOrDefault(x=>x.UserCode==id));
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool UpdateUser(User user)
        {
            User u = db.Users.FirstOrDefault(x=>x.UserCode == user.UserCode);
            if (u != null)
            {
                u.Name=user.Name;
                u.Email=user.Email;
                u.Family=user.Family;
                u.Phone=user.Phone;
                u.FirstAidCertificate=user.FirstAidCertificate;
                u.LoginPassword=user.LoginPassword;
                db.SaveChanges();
                return true;
            }
            return false;
        }

    }
}
