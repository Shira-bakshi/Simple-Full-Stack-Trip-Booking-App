﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.dataT;
using DAL.inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class BookingPlaceBLL : IBookingPlaceBLL
    {
        IBookingPlaceDAL IDal;
        IMapper imapper;
        ITripDAL idt;

        public BookingPlaceBLL(IBookingPlaceDAL iDal,ITripDAL idt)
        {
            IDal = iDal;
            this.idt = idt;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<BookingPlaceDTO> getAllToTrip(int id)
        {
            return imapper.Map<List<BookingPlace>, List<BookingPlaceDTO>>(IDal.getAll().Where(x => x.TripCode == id).ToList());
        }
        public int addB(BookingPlaceDTO bp)
        {
            if (bp.Date > DateTime.Now && bp.TripCode.HasValue && (idt.getById(bp.TripCode.Value).NumberOfAvailablePlaces - bp.NumberOfPlaces) >= 0)
            {
                bp.BookingDate = DateTime.Now;
                bp.BookingTime = DateTime.Now.TimeOfDay;
                idt.getById(bp.TripCode.Value).NumberOfAvailablePlaces -= bp.NumberOfPlaces;
                return IDal.addBookingPlase(imapper.Map<BookingPlaceDTO, BookingPlace>(bp));
            }
            return -1;
        }
        public bool deleteBookingPlace(int id)
        {
            if (IDal.getById(id) != null)
            {
                BookingPlaceDTO b = imapper.Map<BookingPlace, BookingPlaceDTO>(IDal.getById(id));
                int c = b.TripCode.Value;
                TripDTO t = imapper.Map<Trip, TripDTO>(idt.getById(c));
                if (t.Date > DateTime.Now)
                {
                    t.NumberOfAvailablePlaces += b.NumberOfPlaces;
                    return IDal.deletBookingPlase(id);
                }
            }
            return false;
        }
    }
}
