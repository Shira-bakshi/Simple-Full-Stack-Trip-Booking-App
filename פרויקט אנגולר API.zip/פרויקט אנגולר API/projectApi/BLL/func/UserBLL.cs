﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.dataT;
using DAL.func;
using DAL.inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class UserBLL:IUserBLL
    {
        IUserDAL IDal;
        IMapper imapper;
        IBookingPlaceDAL ibp;
        ITripDAL itd;
           
        public UserBLL(IUserDAL iDal, IBookingPlaceDAL ibp, ITripDAL itd)
        {
            IDal = iDal;
            this.ibp = ibp;
            this.itd = itd;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<UserDTO> getAll()
        {
            return imapper.Map<List<User>,List<UserDTO>>(IDal.getAll());
        }
        public UserDTO GetUserByMailAndPassword(string mail,string pass)
        {
            return imapper.Map<User,UserDTO>(IDal.byMailAndPasword(mail, pass));
        }
        public int addUser(UserDTO user)
        {
            if (IDal.byMailAndPasword(user.Email,user.LoginPassword)==null)
                return IDal.addUser(imapper.Map<UserDTO, User>(user));
            return -1;
        }
        public bool updateUser(UserDTO user)
        {

            if (IDal.byMailAndPasword(user.Email, user.LoginPassword) != null)
                return IDal.UpdateUser(imapper.Map<UserDTO,User>(user));
            return false;
        }
        public bool deleteUser(int idUser)
        {
            if (ibp.getAll().FirstOrDefault(x => x.UserCode == idUser) == null)
            {
                return IDal.deletUser(idUser);
            }
            return false;
        }
        public List<TripDTO> getAllTrip(int  idu)
        {
            List<BookingPlaceDTO> bp= imapper.Map<List<BookingPlace>, List<BookingPlaceDTO>>(ibp.getAll().Where(x => x.UserCode == idu).ToList());
            List<TripDTO> t= new List<TripDTO>();
            foreach (BookingPlaceDTO item in bp)
            {
                t.Add(imapper.Map<Trip,TripDTO>(itd.getAll().FirstOrDefault(x => x.TripCode == item.TripCode)));
            }
            return t;
        }

        
    }   
}
