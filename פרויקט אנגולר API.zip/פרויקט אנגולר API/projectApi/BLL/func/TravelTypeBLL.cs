﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.dataT;
using DAL.inter;
using Microsoft.EntityFrameworkCore.Migrations.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class TravelTypeBLL:ITravelTypeBLL
    {
        ITravelTypeDAL IDal;
        IMapper imapper;

        public TravelTypeBLL(ITravelTypeDAL iDal)
        {
            IDal = iDal;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<TravelTypeDTO> getAll()
        {
            return imapper.Map<List<TravelType>, List<TravelTypeDTO>>(IDal.getAll());
        }
        public int AddTravelT(TravelTypeDTO TravelT) 
        {
            if(IDal.getById(TravelT.TypeCode)==null)
              return IDal.addTravel(imapper.Map<TravelTypeDTO,TravelType>(TravelT));
            return -1;
        }
        public bool deletTravelT(int TravelT)
        {
            if (IDal.getById(TravelT)!=null)
                return IDal.deletTravelType(TravelT);

            return false;
        }
    }
}
