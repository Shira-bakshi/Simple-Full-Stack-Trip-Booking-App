﻿using AutoMapper;
using BLL.DTO;
using BLL.inter;
using DAL.dataT;
using DAL.inter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.func
{
    public class TripBLL:ITripBLL
    {
        ITripDAL IDal;
        IMapper imapper;
        IBookingPlaceDAL Ibp;
        public TripBLL(ITripDAL iDal, IBookingPlaceDAL ibp)
        {
            IDal = iDal;
            Ibp = ibp;
            var config = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<mapper>();
            });
            imapper = config.CreateMapper();
        }
        public List<TripDTO> getAll()
        {
            return imapper.Map<List<Trip>,List<TripDTO>>(IDal.getAll());
        }
        public TripDTO getByid(int id)
        {
            return imapper.Map<Trip, TripDTO>(IDal.getById(id));
        }
        public int addTrip(TripDTO t)
        {
            if (IDal.getAll().FirstOrDefault(x => x.TripCode == t.TripCode) == null)
            {
                return IDal.addTrip(imapper.Map<TripDTO, Trip>(t));
            }
            return -1;
        }
        public bool updateTrip(TripDTO t)
        {
            if (IDal.getAll().FirstOrDefault(x => x.TripCode == t.TripCode) != null)
            {
                if(t.Date>DateTime.Now)
                {
                    return IDal.UpdateTrip(imapper.Map<TripDTO,Trip>(t));
                }
            }
            return false;
        }
        public List<BookingPlaceDTO> GetInvitesToTrip(int id)
        {
            return imapper.Map<List<BookingPlace>,List<BookingPlaceDTO>>(Ibp.getAll().Where(x=>x.TripCode == id).ToList());
        }
        public bool deletTrip(int id)
        {
            return IDal.deletTrip(id);
        }


    }
}
