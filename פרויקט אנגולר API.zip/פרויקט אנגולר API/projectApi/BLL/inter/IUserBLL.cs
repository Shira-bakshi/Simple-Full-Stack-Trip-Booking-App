﻿using BLL.DTO;
using DAL.dataT;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.inter
{
    public interface IUserBLL
    {
        public List<UserDTO> getAll();
        public UserDTO GetUserByMailAndPassword(string mail,string pass );
        public int addUser(UserDTO user);
        public bool updateUser(UserDTO user);

        public bool deleteUser(int idUser);
        public List<TripDTO> getAllTrip(int idu);
 
    }
}
