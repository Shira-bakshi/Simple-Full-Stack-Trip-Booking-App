﻿using BLL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.inter
{
    public interface IBookingPlaceBLL
    {
        public List<BookingPlaceDTO> getAllToTrip(int id);
        public int addB(BookingPlaceDTO bp);
        public bool deleteBookingPlace(int id);



    }
}
