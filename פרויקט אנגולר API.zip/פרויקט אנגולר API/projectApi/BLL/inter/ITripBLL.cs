﻿using BLL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.inter
{
    public interface ITripBLL
    {
        public List<TripDTO> getAll();
        public int addTrip(TripDTO t);
        public bool updateTrip(TripDTO t);
        public List<BookingPlaceDTO> GetInvitesToTrip(int id);
        public TripDTO getByid(int id);
        public bool deletTrip(int id);




    }
}
