﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTO
{
    public class TripDTO
    {
        public int TripCode { get; set; }

        public string? TripDestination { get; set; }

        public int? TypeCode { get; set; }

        public DateTime? Date { get; set; }

        public TimeSpan? DepartureTime { get; set; }

        public int? TripDurationHours { get; set; }

        public int? NumberOfAvailablePlaces { get; set; }

        public decimal? Price { get; set; }

        public string? Photo { get; set; }
        public string? TypeName { get; set; }
        public bool? FirstAidCertificate { get; set; }


    }
}
